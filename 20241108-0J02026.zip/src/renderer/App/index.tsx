import { HashRouter as Router, Route, Routes, Link } from 'react-router-dom'
import { TradesHistory } from '../TradesHistory'
import { InputTrades } from 'renderer/InputTrades'
import { GainAndLoss } from 'renderer/GainAndLoss'

const App = () => {
  return (
    <div>
      <Router>
        <Navbar></Navbar>
        <Routes>
          <Route path="/" Component={GainAndLoss} />
          <Route path="/history" Component={TradesHistory} />
          <Route path="/input" Component={InputTrades} />
        </Routes>
      </Router>
    </div>
  )
}

const Navbar = () => {
  return (
    <div className="navbar">
      <ul>
        <li>
          <Link to={'/'}>gal</Link>
        </li>
        <li>
          <Link to={'/history'}>history</Link>
        </li>
        <li>
          <Link to={'/input'}>input</Link>
        </li>
      </ul>
    </div>
  )
}

export default App
