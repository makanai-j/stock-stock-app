import { createContext, Dispatch, useContext, useReducer } from 'react'

type YFOptionsAction =
  | { type: 'setInterval'; interval: YFInterval }
  | { type: 'setPeriod'; period1: Date; period2?: Date }

const YFOptionsContext = createContext<YFOptions | null>(null)
const YFOptionsDispatchContext =
  createContext<Dispatch<YFOptionsAction> | null>(null)

function YFOptionsReducer(
  state: YFOptions,
  action: YFOptionsAction
): YFOptions {
  switch (action.type) {
    case 'setInterval':
      return { ...state, interval: action.interval }
    case 'setPeriod':
      return { ...state, period1: action.period1, period2: action.period2 }
    default:
      return state
  }
}

export function YFOptionsProvider({ children }: { children: any }) {
  const date = new Date()
  date.setDate(date.getDate() - 30)
  const [yfOptions, dispatch] = useReducer(YFOptionsReducer, {
    interval: '1d',
    period1: date,
  })

  return (
    <YFOptionsContext.Provider value={yfOptions}>
      <YFOptionsDispatchContext.Provider value={dispatch}>
        {children}
      </YFOptionsDispatchContext.Provider>
    </YFOptionsContext.Provider>
  )
}

export const useYFOptions = () => useContext(YFOptionsContext)
export const useYFOptionsDispatch = () => useContext(YFOptionsDispatchContext)
