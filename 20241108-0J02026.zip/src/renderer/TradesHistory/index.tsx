import { useEffect, useState } from 'react'
//import { isIntervalString, YFOptions } from '../../types/yfTypes'
import {
  useTradesHistory,
  TradesHistoryProvider,
  useTradesHistoryDispatch,
} from './TradesHistoryContext'
import {
  useYFOptions,
  useYFOptionsDispatch,
  YFOptionsProvider,
} from './YFOptionsContext'
import { FinanceChart } from './components/FinanceCharts'
import { HistoryList } from './components/HistoryList'

/**
 * 履歴画面のページ
 */
export const TradesHistory = () => {
  return (
    <TradesHistoryProvider>
      <YFOptionsProvider>
        <Chart></Chart>
        <HistoryList></HistoryList>
      </YFOptionsProvider>
    </TradesHistoryProvider>
  )
}

const Chart = () => {
  const trades = useTradesHistory()
  const yfOptions = useYFOptions()
  const yfOptionsDispatch = useYFOptionsDispatch()

  const setIntervalYfOption = (e: React.ChangeEvent<HTMLSelectElement>) => {
    yfOptionsDispatch &&
      yfOptionsDispatch({
        type: 'setInterval',
        interval: e.target.value as YFInterval,
      })
  }

  return (
    <>
      {trades?.length ? (
        <div>
          <select value={yfOptions?.interval} onChange={setIntervalYfOption}>
            <option value="5m">5分</option>
            <option value="15m">15分</option>
            <option value="1d">日足</option>
            <option value="1mo">月足</option>
          </select>
          <FinanceChart />
        </div>
      ) : (
        <div>no data</div>
      )}
    </>
  )
}
