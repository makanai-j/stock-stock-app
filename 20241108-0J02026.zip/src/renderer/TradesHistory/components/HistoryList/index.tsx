import { useEffect, useState } from 'react'
import { useTradesHistoryDispatch } from 'renderer/TradesHistory/TradesHistoryContext'
import {
  useYFOptions,
  useYFOptionsDispatch,
} from 'renderer/TradesHistory/YFOptionsContext'

export const HistoryList = () => {
  const [trades, setTrades] = useState<TradeRecordRaw[]>([])
  const tradesDispatch = useTradesHistoryDispatch()
  const yfOptions = useYFOptions()
  const yfOptionsDispatch = useYFOptionsDispatch()

  useEffect(() => {
    window.crudAPI
      .select({ ...yfOptions, mode: 'raw' })
      .then((trades) => setTrades(trades))
  }, [yfOptions])

  const setChartsTrades = (tradeId: string) => {
    window.crudAPI.select({ mode: 'raw', id: tradeId }).then((trades) => {
      if (trades.length) {
        tradesDispatch && tradesDispatch({ type: 'set', trades: trades })

        let period1 = new Date(trades[0].date)
        let period2 = new Date(trades[0].date)

        const chartTrades = trades.sort((a, b) => {
          if (a.date < b.date) return -1
          else if (a.date > b.date) return 1
          return 0
        })
        if (chartTrades.length > 1) {
          period1 = new Date(chartTrades[0].date)
          period2 = new Date(chartTrades[chartTrades.length - 1].date)
        } else if (chartTrades.length == 1) {
          period1.setDate(period1.getDate() - 1)
          period2.setDate(period2.getDate() + 1)
        }

        yfOptionsDispatch &&
          yfOptionsDispatch({
            type: 'setPeriod',
            period1: period1,
            period2: period2,
          })
      }
    })
  }

  return (
    <div>
      {trades.map((trade) => (
        <div onClick={() => setChartsTrades(trade.id)} key={trade.id}>
          <div>{new Date(trade.date).toString()}</div>
          <span>{formatToTime(trade.date)}</span>
          <span>{trade.symbol}</span>
          <span>{trade.company}</span>
          <span>{trade.tradeType}</span>
          <span>{trade.quantity}株</span>
          <span>{trade.price}円</span>
        </div>
      ))}
    </div>
  )
}

const formatToTime = (date: Date | number | string) => {
  date = new Date(date)
  const hours = String(date.getHours()).padStart(2, '0')
  const minutes = String(date.getMinutes()).padStart(2, '0')

  return `${hours}:${minutes}`
}
