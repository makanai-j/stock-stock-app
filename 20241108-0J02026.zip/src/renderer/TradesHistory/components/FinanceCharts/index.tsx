import { useEffect, useRef } from 'react'
import * as echarts from 'echarts'
import { toEChartsData } from './chart/toEChartsData'
import { initialEchartsOption, separatorLine, series, series0 } from './chart/eChartsOption'
import { useTradesHistory } from 'renderer/TradesHistory/TradesHistoryContext'
import { useYFOptions } from 'renderer/TradesHistory/YFOptionsContext'
//import { YFOptions } from '../../../../types/yfTypes'

/**
 * 株のチャート
 *
 * @param yfSymbol - 銘柄コード
 * @param yfOption - 足の間隔, 開始・終了日時
 */
export const FinanceChart = () => {
  const chartRef = useRef<HTMLDivElement>(null)
  const trades = useTradesHistory()
  const yfOptions = useYFOptions()

  useEffect(() => {
    console.log('create chart')
    const myCharts = echarts.init(chartRef.current)

    if (!trades?.length || !yfOptions) return

    console.log(yfOptions)
    window.electronAPI
      .financeData(`${trades[0].symbol}${trades[0].placeYF}`, yfOptions)
      .then((data) => {
        const eChartsData = toEChartsData(data, yfOptions.interval)
        console.log(data)
        console.log(eChartsData)
        myCharts?.setOption(
          {
            ...initialEchartsOption,
            xAxis: [
              {
                ...initialEchartsOption.xAxis[0],
                data: eChartsData.xAxisData,
              },
              {
                ...initialEchartsOption.xAxis[1],
                data: eChartsData.xAxisData0,
              },
              {
                ...initialEchartsOption.xAxis[2],
                data: eChartsData.xAxisData1,
              },
            ],
            series: [
              {
                ...series,
                data: eChartsData.yAxisData,
              },
              {
                ...series0,
                markLine: {
                  data: eChartsData.markLineData,
                  ...separatorLine
                }
              },
            ],
          },
          true
        )
      })
      .catch((err) => {
        console.log(err)
      })
  })

  return (
    <div>
      <div ref={chartRef} style={{ width: '500px', height: '500px' }}></div>
    </div>
  )
}
