const dateFormat: { [period: string]: 'numeric' | '2-digit' } = {
  //year: "numeric",
  //month: "2-digit",
  //day: "2-digit",
  hour: 'numeric',
  minute: '2-digit',
}

// static
const axisPointer = {
  link: [{ xAxisIndex: 'all' }],
  show: true,
}
const grid = [
  {
    left: 10,
    right: 10,
    top: 15,
    containLabel: true,
  },
]
const yAxis = {
  scale: true,
  splitArea: {
    show: true,
  },
  position: 'right',
  axisLabel: {
    fontSize: 10,
  },
  axisPointer: {
    label: {
      fontSize: 9,
    },
  },
}
const tooltip = {
  trigger: 'axis',
  xAxisIndex: 0,
  axisPointer: {
    type: 'cross',
  },
  textStyle: {
    fontFamily: 'monospace',
  },
  position: function (
    pos: number[],
    _params: any,
    _el: any,
    _elRect: any,
    size: { contentSize: number[]; viewSize: number[] }
  ) {
    const obj: { [position: string]: number } = { top: 10 }
    if (pos[0] < size.viewSize[0] / 2) obj.right = 55
    else obj.left = 10
    return obj
  },
  formatter: (params: any) => {
    if (!params.length || !params[0].axisValue || params[0].data.length !== 5)
      return

    params = params[0]
    let dataStr = `<div>${params.marker}${params.axisValue}</div>`

    const labelMap = ['始値', '終値', '安値', '高値']
    params.data.forEach((value: number, index: number) => {
      if (index == 0) return
      dataStr += `
            <div style='display: flex'>
                <div style='margin-left: 5%'>
                ${labelMap[index - 1]}
                </div>
                <div style='margin-left: auto; margin-right: 5%'>${value}</div>
            </div>
        `
    })
    return dataStr
  },
}

const dataZoom = [
  {
    type: 'inside',
    start: 98,
    end: 100,
    minValueSpan: 14,
  },
  {
    show: true,
    type: 'slider',
    bottom: 35,
    height: 25,
    start: 98,
    end: 100,
    minValueSpan: 14,
    labelFormatter: () => '',
  },
]

//
export const xAxis = {
  type: 'category',
  data: <string[]>[],
  show: false,
  position: 'bottom',
}
export const xAxis0 = {
  ...xAxis,
  show: true,
  boundaryGap: true,
  axisLine: { onZero: false },
  splitLine: { show: false },
  axisTick: {
    alignWithLabel: false,
  },
  axisLabel: {
    align: 'center',
    fontSize: 10,
  },
  axisPointer: {
    show: false,
  },
}
export const xAxis1 = {
  ...xAxis0,
  position: 'top',
  axisLine: {
    show: false,
  },
  axisTick: {
    show: true,
    alignWithLabel: true,
    lineStyle: {
      color: 'gray',
      type: 'solid', //[0.5, 2.5],
      opacity: 0.2,
    },
    // interval: (index: number, value: string) => {
    //   if (index == 0) return true
    //   return value != ''
    // },
    // alignWithLabel: false,
    // inside: true,
    // length: 365,
    // lineStyle: {
    //   color: 'gray',
    //   type: 'solid', //[0.5, 2.5],
    //   opacity: 0.2,
    // },
  },
  axisLabel: {
    /*
    formatter: function (value: string) {
      if (!value) return ''
      const date: Date = new Date(value)
      return date.toLocaleDateString('ja-JP', dateFormat)
    },*/
    align: 'left',
    fontSize: 9,
    interval: (index: number, value: string) => {
      return value != ''
    },
  },
  axisPointer: {
    show: false,
  },
}
export const series = {
  type: 'candlestick',
  barWidth: '85%',
  itemStyle: {
    color: '#FF0055',
    color0: '#12DDD6',
    borderColor: '#FF0055',
    borderColor0: '#12DDD6',
  },
  data: <number[][]>[],
  markLine: {
    data: [],
    symbol: 'none',
    silent: true,
    lineStyle: {
      color: '#f40',
      type: [5, 10],
      opacity: 0.5,
    },
    emphasis: {
      disabled: true,
    },
    label: { show: false },
    /*
    label: {
      show: true,
      fontSize: 9,
      color: "#0f0",
      position: "insideEndTop"
    },*/ animation: false,
  },
}
export const series0 = {
  type: 'candlestick',
  xAxisIndex: 2,
  data: [],
  markLine: {
    data: [
      {
        xAxis: '10月',
        //coord: [0,1]
      },
    ],
    symbol: 'none',
    silent: true,
    lineStyle: {
      color: '#40f',
      type: [5, 10],
      opacity: 0.7,
    },
    emphasis: {
      disabled: true,
    },
    label: { show: false } /*
    label: {
      show: true,
      fontSize: 9,
      color: "#00f",
      position: "insideEndBottom"
    },*/,
    animation: false,
  },
}

export const separatorLine = {
  symbol: 'none',
  silent: true,
  lineStyle: {
    color: 'gray',
    type: 'solid',
    opacity: 0.2,
  },
  emphasis: {
    disabled: true,
  },
  label: { show: false },
  animation: false,
}

/**
 * eChartsの初期設定
 */
export const initialEchartsOption = {
  axisPointer,
  grid,
  xAxis: [xAxis, xAxis0, xAxis1],
  yAxis,
  series: [series, series0],
  tooltip,
  dataZoom,
}
