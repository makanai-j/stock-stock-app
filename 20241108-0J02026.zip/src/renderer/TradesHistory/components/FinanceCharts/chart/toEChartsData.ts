//import { YFChartObject } from '../../../../../types/yfTypes'

type EChartsData = {
  xAxisData: string[]
  xAxisData0: string[]
  xAxisData1: string[]
  yAxisData: number[][]
  markLineData: { xAxis: string }[]
}

/**
 *
 * @param yfChartDatas yahoo-financeAPIからの株式価格オブジェクト
 * @param interval 足の間隔
 * @returns eCharts用の軸データとマークラインデータ
 */
export const toEChartsData = (
  yfChartDatas: YFChartObject[],
  interval: YFInterval = '5m'
): EChartsData => {
  const eChartsData: EChartsData = {
    xAxisData: [],
    xAxisData0: [],
    xAxisData1: [],
    yAxisData: [],
    markLineData: [],
  }

  for (let i = 0; i < yfChartDatas.length; i++) {
    const chartData = yfChartDatas[i]
    const m: Intl.DateTimeFormatOptions = {
      hour: 'numeric',
      minute: '2-digit',
    }
    const d: Intl.DateTimeFormatOptions = {
      day: 'numeric',
    }
    const mo: Intl.DateTimeFormatOptions = {
      month: 'numeric',
    }
    const formatMap: Record<YFInterval, Intl.DateTimeFormatOptions> = {
      ...Object.fromEntries(
        (['1m', '2m', '5m', '15m', '30m', '60m', '90m', '1h'] as const).map(
          (key) => [key, m]
        )
      ),
      ...Object.fromEntries(['1d', '5d', '1wk'].map((key) => [key, d])),
      ...Object.fromEntries(['1mo', '3mo'].map((key) => [key, mo])),
    } as Record<YFInterval, Intl.DateTimeFormatOptions>

    const mF: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    }
    const dF: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }
    const moF: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'short',
    }
    const formatFullMap: Record<YFInterval, Intl.DateTimeFormatOptions> = {
      ...Object.fromEntries(
        (['1m', '2m', '5m', '15m', '30m', '60m', '90m', '1h'] as const).map(
          (key) => [key, mF]
        )
      ),
      ...Object.fromEntries(['1d', '5d', '1wk'].map((key) => [key, dF])),
      ...Object.fromEntries(['1mo', '3mo'].map((key) => [key, moF])),
    } as Record<YFInterval, Intl.DateTimeFormatOptions>

    if (!chartData.open) {
      continue
    }

    const y = [
      chartData.open,
      chartData.close,
      chartData.low,
      chartData.high,
    ].map((value) => Math.round(value * 100) / 100)

    /* 一定間隔で上部に日付表示
     足の間隔によってDateのフォーマットを変える
     index == 0 の時に値を入れないと線が出ないバグが発生するみたい */
    // 前のデータの日時要素
    const preDate: Date = yfChartDatas[i == 0 ? 0 : i - 1].date
    const date: Date = chartData.date
    switch (interval) {
      case '1d':
      case '5d':
      case '1wk':
        if (date.getMonth() !== preDate.getMonth()) {
          eChartsData.xAxisData.push(`${date.getMonth() + 1}月`)
          eChartsData.xAxisData0.push('')
          eChartsData.xAxisData1.push(`${date.getMonth() + 1}月`, '')
          eChartsData.yAxisData.push([])
          eChartsData.markLineData.push({ xAxis: `${date.getMonth() + 1}月` })
        } else eChartsData.xAxisData1.push('')
        break
      case '1mo':
      case '3mo':
        if (date.getFullYear() !== preDate.getFullYear()) {
          eChartsData.xAxisData.push(`${date.getFullYear()}年`)
          eChartsData.xAxisData0.push('')
          eChartsData.xAxisData1.push(`${date.getFullYear()}年`, '')
          eChartsData.yAxisData.push([])
          eChartsData.markLineData.push({ xAxis: `${date.getFullYear()}年` })
        } else eChartsData.xAxisData1.push('')
        break
      // 1m - 90m , 1h
      default:
        if (date.getDate() !== preDate.getDate()) {
          eChartsData.xAxisData.push(`${date.getDate()}日`)
          eChartsData.xAxisData0.push('')
          eChartsData.xAxisData1.push(`${date.getDate()}日`, '')
          eChartsData.yAxisData.push([])
          eChartsData.markLineData.push({ xAxis: `${date.getDate()}日` })
        } else eChartsData.xAxisData1.push('')
    }
    eChartsData.xAxisData.push(
      chartData.date.toLocaleString('ja-JP', formatFullMap[interval])
    )
    eChartsData.xAxisData0.push(
      chartData.date.toLocaleString('en-GB', formatMap[interval])
    )
    //eChartsData.xAxisData1.push(addDateLabel())

    eChartsData.yAxisData.push(y)
  }
  return eChartsData
}
