import React from 'react'
import TextField, { TextFieldProps } from '@mui/material/TextField'

const MyTextField = React.forwardRef(
  (props: TextFieldProps, ref: React.Ref<HTMLDivElement>) => {
    return (
      <TextField
        {...props}
        sx={{
          '& .MuiInputBase-input': {
            fontSize: 13,
            width: 115,
            height: 15,
            padding: 1,
          },
          svg: { padding: '3px 0 3px 2px', width: '17px', height: '17px' },
        }}
        ref={ref}
      />
    )
  }
)

export default MyTextField
