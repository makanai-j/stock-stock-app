export const getDayCustom = (date: Date) => {
  const startDay = 1
  return (date.getDay() + (7 - startDay)) % 7
}
