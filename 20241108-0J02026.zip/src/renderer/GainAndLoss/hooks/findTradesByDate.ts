import { getDayCustom } from './getDayCustom'
import { isInSameLongPeriod } from './isSamePeriod'

export const findTradesByDate = (
  galGroupedByLongPeriod: TradeRecordGAL[][][],
  selectedDate: Date,
  interval: GALInterval
) => {
  for (let i = 0; i < galGroupedByLongPeriod.length; i++) {
    const galGroupedByPeriod = galGroupedByLongPeriod[i]
    const currDate = new Date(galGroupedByPeriod[0][0].date)
    if (interval == '1w')
      currDate.setDate(currDate.getDate() - getDayCustom(currDate))
    if (isInSameLongPeriod(interval, selectedDate, currDate))
      return galGroupedByPeriod
  }
  return null
}
