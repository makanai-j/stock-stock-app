import { getDayCustom } from './getDayCustom'
import { isInSameShortPeriod, isInSameLongPeriod } from './isSamePeriod'

export const aggregateTradeGAL = (
  interval: GALInterval,
  trades: TradeRecordGAL[]
): TradeRecordGAL[][][] => {
  if (!trades.length) return []

  const galGroupedByPeriod: TradeRecordGAL[][] = []
  let currentGroup: TradeRecordGAL[] = [trades[0]]

  for (let i = 1; i < trades.length; i++) {
    if (
      isInSameShortPeriod(
        interval,
        new Date(trades[i - 1].date),
        new Date(trades[i].date)
      )
    ) {
      currentGroup.push(trades[i])
    } else {
      galGroupedByPeriod.push(currentGroup)
      currentGroup = [trades[i]]
    }
  }
  galGroupedByPeriod.push(currentGroup)

  const galGroupedByLongPeriod: TradeRecordGAL[][][] = []
  let longPeriodGroup: TradeRecordGAL[][] = [galGroupedByPeriod[0]]

  for (let i = 1; i < galGroupedByPeriod.length; i++) {
    const prevDate = new Date(galGroupedByPeriod[i - 1][0].date)
    const currDate = new Date(galGroupedByPeriod[i][0].date)
    if (interval == '1w') {
      prevDate.setDate(prevDate.getDate() - getDayCustom(prevDate))
      currDate.setDate(currDate.getDate() - getDayCustom(currDate))
    }
    const isNewPeriod = !isInSameLongPeriod(interval, prevDate, currDate)

    if (isNewPeriod) {
      galGroupedByLongPeriod.push(longPeriodGroup)
      longPeriodGroup = [galGroupedByPeriod[i]]
    } else {
      longPeriodGroup.push(galGroupedByPeriod[i])
    }
  }
  galGroupedByLongPeriod.push(longPeriodGroup)

  return galGroupedByLongPeriod
}
