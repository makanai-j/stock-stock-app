import { isInputElement } from 'react-router-dom/dist/dom'
import { aggregateTradeGAL } from 'renderer/GainAndLoss/hooks/aggregateTradeGAL'
import { findTradesByDate } from 'renderer/GainAndLoss/hooks/findTradesByDate'

/**
 *
 * @param yfChartDatas yahoo-financeAPIからの株式価格オブジェクト
 * @param interval 足の間隔
 * @returns eCharts用の軸データとマークラインデータ
 */
export const toEChartsData = (
  tradeGALs: TradeRecordGAL[],
  date: Date,
  interval: GALInterval
): EChartsDataGAL => {
  let total = 0
  const eChartsData: EChartsDataGAL = {
    xAxisData: [],
    xAxisData0: [],
    xAxisData1: [],
    yAxisData: [],
    yAxisData0: [],
  }

  // dateで昇順
  const galGroupedByLongPeriod = aggregateTradeGAL(interval, tradeGALs)

  for (let i = 0; i < galGroupedByLongPeriod.length; i++) {
    const tradesGroup = galGroupedByLongPeriod[i]
    const t = findTradesByDate([tradesGroup], date, interval)

    if (t) {
      const formatMap: { [key in GALInterval]: Intl.DateTimeFormatOptions } = {
        '1d': { day: 'numeric' },
        '1w': { month: 'numeric', day: 'numeric' },
        '1mo': { month: 'numeric' },
        '1y': { year: 'numeric' },
      }
      const formatMap0: { [key in GALInterval]: Intl.DateTimeFormatOptions } = {
        '1d': { year: 'numeric', month: 'short', day: 'numeric' },
        '1w': { year: 'numeric', month: 'short', day: 'numeric' },
        '1mo': { year: 'numeric', month: 'short' },
        '1y': { year: 'numeric' },
      }

      const format = formatMap[interval]
      const format0 = formatMap0[interval]
      eChartsData.yAxisData = []

      tradesGroup.forEach((trades, index) => {
        let periodTotal = 0
        trades.forEach((trade) => (periodTotal += trade.gal * trade.quantity))

        const tradeDate = new Date(trades[0].date)
        eChartsData.xAxisData.push(
          tradeDate.toLocaleDateString('ja-JP', format0)
        )

        eChartsData.xAxisData0.push(tradeDate.toLocaleDateString('en', format))

        if (
          interval == '1w' &&
          (index == 0 ||
            new Date(tradesGroup[index - 1][0].date).getMonth() !=
              tradeDate.getMonth())
        ) {
          eChartsData.xAxisData1.push('1')
        } else {
          eChartsData.xAxisData1.push('')
        }

        total += periodTotal
        eChartsData.yAxisData.push(total)
        eChartsData.yAxisData0.push(periodTotal)
      })
    } else {
      if (date < new Date(tradesGroup[0][0].date)) break

      tradesGroup.forEach((trades) =>
        trades.forEach((trade) => (total += trade.gal * trade.quantity))
      )

      eChartsData.yAxisData = [total, total]
    }
  }

  return eChartsData
}
