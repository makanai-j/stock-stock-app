// static
const axisPointer = {
  link: [{ xAxisIndex: 'all' }],
  show: true,
}
const grid = [
  {
    left: 10,
    right: 10,
    top: 15,
    containLabel: true,
  },
]
const yAxis = [
  {
    type: 'value',
    axisLabel: {
      fontSize: 10,
    },
    axisPointer: {
      show: false,
      // label: {
      //   fontSize: 9,
      // },
    },
  },
]
const tooltip = {
  trigger: 'axis',
  //   axisPointer: {
  //     type: 'cross',
  //     crossStyle: {
  //       color: '#999',
  //     },
  //   },
  textStyle: {
    fontFamily: 'monospace',
  },
  valueFormatter: (value: number, _: number) =>
    value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '円',
  position: function (
    pos: number[],
    _params: any,
    _el: any,
    _elRect: any,
    size: { contentSize: number[]; viewSize: number[] }
  ) {
    const obj: { [position: string]: number } = { top: 10 }
    if (pos[0] < size.viewSize[0] / 2) obj.right = 10
    else obj.left = 10
    return obj
  },
}

//
export const xAxis = {
  type: 'category',
  data: <string[]>[],
  show: false,
  position: 'bottom',
  axisPointer: {
    type: 'shadow',
  },
}

export const xAxis0 = {
  ...xAxis,
  show: true,
  axisTick: {
    show: true,
    alignWithLabel: false,
    inside: false,
  },
  axisLabel: {
    align: 'center',
    fontSize: 9,
    interval: (_: number, value: string) => {
      return value != ''
    },
  },
  axisPointer: {
    show: false,
  },
}

export const xAxis1 = {
  ...xAxis,
  boundaryGap: true,
  axisLine: { onZero: false },
  splitLine: { show: false },
  show: true,
  position: 'bottom',
  axisTick: {
    show: true,
    interval: (_: number, value: string) => {
      return value !== ''
    },
    alignWithLabel: false,
    inside: true,
    length: 380,
    lineStyle: {
      color: 'gray',
      type: 'solid', //[0.5, 2.5],
      opacity: 0.2,
    },
  },
  axisLabel: {
    show: false,
  },
  axisPointer: {
    show: false,
  },
}

export const series = {
  name: '経過損益' as const,
  type: 'line',
  itemStyle: {
    color: '#5c5',
  },
  data: <number[]>[],
}
export const series0 = {
  name: '期間損益' as const,
  type: 'bar',
  itemStyle: {
    color: (value: any) => {
      return value.value < 0 ? '#c33' : '#33c'
    },
  },
  data: <number[]>[],
}

/**
 * eChartsの初期設定
 */
export const initialEchartsOption = {
  //axisPointer,
  grid,
  xAxis: [xAxis, xAxis0, xAxis1],
  yAxis,
  series: [series, series0],
  tooltip,
}
